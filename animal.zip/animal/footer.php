<?php global $animall; ?>

<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package ready
 */

?>
<footer>
			<div class="zerogrid wrap-footer">



				<div class="row">

						<?php dynamic_sidebar('sidebar-1') ?>


				
				

				

				</div>
 



			</div>
			<div class="copyright">
				<div class="zerogrid wrapper">
					Copyright @ zAnimal - Designed by <a href="https://www.zerotheme.com" title="free website templates">
						
						<?php echo $animall['at'];?>
							
						</a>

					<!-- <ul class="quick-link">
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Terms of Use</a></li>
					</ul> -->

					<?php 

					wp_nav_menu([

						'menu_class'	=>'quick-link',
						'theme_location'	=>'footer-menu',
						'container'			=>' '

					])


					 ?>
				</div>
			</div>
		</footer>
	</div>

	<?php wp_footer(); ?>
</body>
</html>